//@ts-nocheck
import {items} from "../config";

export function getCities(){
    return Object.keys(items)
}

export function getItems(){

}

export function getOrderNumber(){
    global.orderNumber = global.orderNumber || 27583969
    global.orderNumber += 3
    return global.orderNumber
}
