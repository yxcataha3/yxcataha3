// noinspection NonAsciiCharacters

import {v4 as uuidv4} from 'uuid';

export const TOKEN = ''

export const PRICE_PLUS_RANGE = 10
export const PLUS_PERCENT = 10
export const MAIN_MENU_FIRST_TEXT = ''
export const MAIN_MENU_SECOND_TEXT = ''
export const OPERATOR_URL = 'https://t.me/KMRR247KUZ'
export const PRICE_URL = 'https://clck.ru/dZG5k'
export const ORDER_CANCEL_DELAY = 1800
export const RANDOM_CARD_CHOICE = false
export const REFERRAL_PROGRAM = true
export const CARD_NUMBERS = [
    '2200730241180948',
    '4890494782487466',
    '2200730248811594'
]
export const PROBLEM_WITH_PAYMENT_BUTTON_URL = 'https://t.me/doc_tor001'
// @ts-ignore
export const items = {
    "Сочи 🏞": {
        "Заречный": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            // {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            // {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            // {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
        "Донская": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            // {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            // {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            // {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
        "Макаренко": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            // {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            // {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            // {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
        "Новый Сочи": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            // {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            // {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            // {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            // {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
    },
    "Адлер🌇": {
        "Центр": [
            {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            // {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            // {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            // {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            // {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
        "Голубые Дали": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            // {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            // {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
        "Известия": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            // {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            // {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            // {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            // {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
        "Черешня": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            // {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            // {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            // {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
        "Чкаловский": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            // {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            // {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            // {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
    },
    "Лазаревское 🌇": {
        "По городу": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            // {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
    },
    "Туапсе 🏙": {
        "Гизель-Дере": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            // {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
        "Холодный Родник": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            // {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
        "село Вольное": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            // {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            // {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            // {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
        "Центральный": [
            {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            // {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            // {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
        "Шепси": [
            {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            // {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            // {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
        "Кадош": [
            // {title: 'Меф Игла VHQ 1гр Ⓜ️', price: 4000, id: uuidv4()},
            // {title: 'Меф Игла VHQ 1,5гр Ⓜ️', price: 5800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 2гр Ⓜ️', price: 7800, id: uuidv4()},
            // {title: 'Меф Игла VHQ 3гр Ⓜ️', price: 10000, id: uuidv4()},
            // {title: 'Крб 0.5 гр ⚪️', price: 2000, id: uuidv4()},
            // {title: 'Крб 0.75 гр ⚪️', price: 2300, id: uuidv4()},
            // {title: 'Крб 1 гр ⚪️', price: 3000, id: uuidv4()},
            // {title: 'Гашиш 2гр 🧱 (Магнит)', price: 7700, id: uuidv4()},
            // {title: 'Гашиш 3гр 🧱 (Магнит)', price: 9200, id: uuidv4()},
            // {title: 'Гашиш 5гр 🧱 (Магнит)', price: 12000, id: uuidv4()},
        ],
    },
    "Предзаказ товара от 5гр.": {
        "По городу": [
            // {title: 'Предзаказ товара Меф Игла 5гр Ⓜ️', price: 45000, id: uuidv4()},
        ],
    },
    "Гагра 🌃": {
        "По городу": [
            {title: 'Предзаказ товара Меф Игла 5гр Ⓜ️', price: 45000, id: uuidv4()},
        ],
    },
    "Сухум 🌉": {
        "По городу": [
            {title: 'Предзаказ товара Меф Игла 5гр Ⓜ️', price: 45000, id: uuidv4()},
        ],
    },
}
